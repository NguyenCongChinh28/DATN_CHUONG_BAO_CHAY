#ifndef __EXAMPLE_HAL_GPIO_IRQ_H__
#define __EXAMPLE_HAL_GPIO_IRQ_H__

void ExampleHALGpioIrq(void);

#endif //end of __EXAMPLE_HAL_GPIO_IRQ_H__
