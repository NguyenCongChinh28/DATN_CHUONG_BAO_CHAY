#ifndef __EXAMPLE_HAL_SPI_INIT_H__
#define __EXAMPLE_HAL_SPI_INIT_H__
//Ӳ���޹ص�
#include "common.h"
//Ӳ����ص�

common_ret ExampleSpiInit(void);

#endif //end of __EXAMPLE_HAL_SPI_INIT_H__
