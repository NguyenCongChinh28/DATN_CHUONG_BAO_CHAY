#ifndef __EXAMPLE_HAL_GPIO_IN_OUT_H__
#define __EXAMPLE_HAL_GPIO_IN_OUT_H__

void ExampleHALGpioInOut(void);

#endif	//end of __EXAMPLE_HAL_GPIO_IN_OUT_H__
