#include "common.h"

#ifndef ENABLE_INFO_LOG
	char tmp_print_buf[AT_SERVICE_BUFLEN]={0};
#endif /*endof ENABLE_INFO_LOG */
