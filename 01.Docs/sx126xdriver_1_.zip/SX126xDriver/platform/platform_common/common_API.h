#ifndef __COMMON_API_H__
#define __COMMON_API_H__

#endif	/*end of __COMMON_API_H__*/
