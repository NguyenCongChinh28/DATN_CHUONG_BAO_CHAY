#ifndef __HAL_UART_H__
#define __HAL_UART_H__

#include "stm32f10x.h"

uint8_t HALUart1Init(void);

#endif //__HAL_UART_H__
