#ifndef __SX126X_EXAMPLE_RECIVE_H__
#define __SX126X_EXAMPLE_RECIVE_H__

void ExampleSX126xReciveDemo(void);

#endif //end of __SX126X_EXAMPLE_RECIVE_H__
