#ifndef __SX126X_EXAMPLE_SEND_H__
#define __SX126X_EXAMPLE_SEND_H__

void ExampleSX126xSendDemo(void);

#endif //end of __SX126X_EXAMPLE_SEND_H__
