.. _um:

User manual
===========

.. toctree::
    :maxdepth: 2

    how-it-works
    events
    hw-dma-usage
    thread-safety