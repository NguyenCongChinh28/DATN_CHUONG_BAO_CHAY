/*
 * Config.h
 *
 *  Created on: Nov 18, 2021
 *      Author: Admin
 */

#ifndef LORA_DRIVERS_ALOHA_PROTOCOL_CONFIG_H_
#define LORA_DRIVERS_ALOHA_PROTOCOL_CONFIG_H_


#include "Layer1.h"
#include "Types.h"





#define MAXNODES			5

#define NODEID  	2u





#endif /* LORA_DRIVERS_ALOHA_PROTOCOL_CONFIG_H_ */
